package com.liveasy.liveasy.Dao;

import com.liveasy.liveasy.entities.Load;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LoadDao extends JpaRepository<Load,Integer> {
}
