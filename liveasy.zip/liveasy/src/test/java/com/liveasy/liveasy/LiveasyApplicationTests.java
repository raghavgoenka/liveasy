package com.liveasy.liveasy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LiveasyApplicationTests {

	@Test
	void contextLoads() {
	}

}
